# XRay Mod — Minecraft 1.21.1 (Fabric)

มองเห็นแร่ทะลุบล็อกได้ด้วยการกด **X**

## ฟีเจอร์
- กด `X` เพื่อเปิด/ปิด XRay
- เมื่อเปิด จะซ่อนบล็อกทั่วไปทั้งหมด คงเหลือแต่แร่ให้มองเห็น
- รองรับแร่ vanilla ทุกชนิด และแร่จาก **MoreOres** mod ด้วย

## แร่ที่แสดง
**Vanilla:** Coal, Iron, Copper, Gold, Redstone, Lapis, Diamond, Emerald, Nether Quartz, Nether Gold, Ancient Debris

**MoreOres:** Ruby, Sapphire, Topaz, Jade, Peridot, Pyrope, Green/Blue/Pink Garnet, Green Sapphire, White Topaz, Kyawthuite

## วิธีติดตั้ง
1. ติดตั้ง [Fabric Loader](https://fabricmc.net/use/) สำหรับ MC 1.21.1
2. ดาวน์โหลด [Fabric API](https://modrinth.com/mod/fabric-api)
3. วางไฟล์ `.jar` ลงใน `mods/` folder

## วิธี build
```bash
./gradlew build
```
ไฟล์ `.jar` จะอยู่ที่ `build/libs/xray-mod-1.0.0.jar`

## หมายเหตุ
- mod นี้เป็น **client-side only** ใช้ได้ทั้ง singleplayer และ multiplayer
- บางเซิร์ฟเวอร์อาจมี anti-cheat ตรวจจับการใช้ XRay ได้
