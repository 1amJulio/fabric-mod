package com.xraymod;

import net.minecraft.block.Block;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.HashSet;
import java.util.Set;

public class XRayOreList {

    private static final Set<String> ORE_IDS = new HashSet<>();

    static {
        // Vanilla ores
        add("minecraft:coal_ore");
        add("minecraft:deepslate_coal_ore");
        add("minecraft:iron_ore");
        add("minecraft:deepslate_iron_ore");
        add("minecraft:copper_ore");
        add("minecraft:deepslate_copper_ore");
        add("minecraft:gold_ore");
        add("minecraft:deepslate_gold_ore");
        add("minecraft:redstone_ore");
        add("minecraft:deepslate_redstone_ore");
        add("minecraft:lapis_ore");
        add("minecraft:deepslate_lapis_ore");
        add("minecraft:diamond_ore");
        add("minecraft:deepslate_diamond_ore");
        add("minecraft:emerald_ore");
        add("minecraft:deepslate_emerald_ore");
        add("minecraft:nether_quartz_ore");
        add("minecraft:nether_gold_ore");
        add("minecraft:ancient_debris");

        // MoreOres mod ores
        add("moreores:ruby_ore");
        add("moreores:deepslate_ruby_ore");
        add("moreores:sapphire_ore");
        add("moreores:deepslate_sapphire_ore");
        add("moreores:topaz_ore");
        add("moreores:deepslate_topaz_ore");
        add("moreores:jade_ore");
        add("moreores:deepslate_jade_ore");
        add("moreores:peridot_ore");
        add("moreores:deepslate_peridot_ore");
        add("moreores:pyrope_ore");
        add("moreores:deepslate_pyrope_ore");
        add("moreores:green_garnet_ore");
        add("moreores:deepslate_green_garnet_ore");
        add("moreores:blue_garnet_ore");
        add("moreores:deepslate_blue_garnet_ore");
        add("moreores:pink_garnet_ore");
        add("moreores:deepslate_pink_garnet_ore");
        add("moreores:green_sapphire_ore");
        add("moreores:deepslate_green_sapphire_ore");
        add("moreores:white_topaz_ore");
        add("moreores:deepslate_white_topaz_ore");
        add("moreores:kyawthuite_ore");
        add("moreores:deepslate_kyawthuite_ore");
    }

    private static void add(String id) {
        ORE_IDS.add(id);
    }

    public static boolean isOre(Block block) {
        Identifier id = Registries.BLOCK.getId(block);
        return ORE_IDS.contains(id.toString());
    }
}
