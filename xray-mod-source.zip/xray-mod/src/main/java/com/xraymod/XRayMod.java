package com.xraymod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class XRayMod implements ClientModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("xraymod");
    public static boolean xrayEnabled = false;

    private static KeyBinding xrayKey;

    @Override
    public void onInitializeClient() {
        xrayKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xraymod.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_X,
                "category.xraymod"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (xrayKey.wasPressed()) {
                xrayEnabled = !xrayEnabled;
                if (client.player != null) {
                    client.player.sendMessage(
                            Text.literal("§6[XRay] §r" + (xrayEnabled ? "§aเปิดแล้ว ✓" : "§cปิดแล้ว ✗")),
                            true
                    );
                }
                // Force chunk re-render
                if (client.worldRenderer != null) {
                    client.worldRenderer.reload();
                }
                LOGGER.info("XRay toggled: {}", xrayEnabled);
            }
        });

        LOGGER.info("XRay Mod loaded! Press X to toggle.");
    }
}
